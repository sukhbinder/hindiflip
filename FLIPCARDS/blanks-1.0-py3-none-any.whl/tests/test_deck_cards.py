import pytest
import io


def test_deck():
    pass